<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Toko Online</title>
</head>
<body>
    <h1>Selamat Datang di Toko Online!</h1>
    <p><a href="confirm.php">Cek Koneksi Database</a></p>
    <p><a href="database/toko_online.sql" download>📦 Download Database SQL</a></p>
</body>
</html>