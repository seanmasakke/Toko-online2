#!/usr/bin/env bash
    # Quick API smoke tests. Update BASE_URL to your server root (including path to public)
    BASE_URL="http://localhost/api-php-native/public"

    echo "1) Attempt login with invalid credentials (should 401)"
    curl -s -o /dev/null -w "%{http_code}\n" -X POST "$BASE_URL/api/v1/auth/login" -H "Content-Type: application/json" -d '{"identifier":"noone","password":"bad"}'

    echo "2) Create a test user via direct DB or use existing user; here we assume a user exists."
    echo "3) Login as existing user to get token (replace identifier/password below)"
    RESP=$(curl -s -X POST "$BASE_URL/api/v1/auth/login" -H "Content-Type: application/json" -d '{"identifier":"admin","password":"adminpass"}')
    echo "Login response: $RESP"

    TOKEN=$(echo $RESP | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
    if [ -z "$TOKEN" ]; then
        echo "No token retrieved. Edit the script to use valid credentials for an existing user."
        exit 1
    fi
    echo "Token: $TOKEN"

    echo "4) Get users (should return 200)"
    curl -s -o /dev/null -w "%{http_code}\n" -H "Authorization: Bearer $TOKEN" "$BASE_URL/api/v1/users"

    echo "5) Create new user (requires auth)"
    curl -s -X POST "$BASE_URL/api/v1/users" -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" -d '{"username":"testuser","email":"testuser@example.com","password":"secret123"}' -w "
HTTP:%{http_code}
"

    echo "6) Update user id 1 (example)"
    curl -s -X PUT "$BASE_URL/api/v1/users/1" -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" -d '{"email":"changed+test@example.com"}' -w "
HTTP:%{http_code}
"

    echo "7) Delete user id 1 (example)"
    curl -s -X DELETE "$BASE_URL/api/v1/users/1" -H "Authorization: Bearer $TOKEN" -w "\nHTTP:%{http_code}\n"
