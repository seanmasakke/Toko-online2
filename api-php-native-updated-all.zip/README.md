

## Added features by assistant
- .env support (simple parser)
- Dynamic base path routing
- JWT authentication (login at POST /api/v1/auth/login)
- Protected user endpoints (require Bearer token)
- Stronger validation for user input
- tests/api_test.sh script for basic smoke tests

Update .env JWT_SECRET to a strong value.
