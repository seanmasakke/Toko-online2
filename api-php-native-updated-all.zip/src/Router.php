<?php
class Router {
    private $routes = [];

    // $options can have 'auth' => true to require JWT auth
    public function add($method, $path, $callback, $options = []) {
        $this->routes[] = compact('method', 'path', 'callback', 'options');
    }

    private function getBasePath() {
        // compute base path from script name, e.g. /project/public/index.php -> /project/public
        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
        $base = rtrim(dirname($script), '/');
        if ($base === '' || $base === '\\') $base = '/';
        return $base;
    }

    public function run() {
        $requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $requestMethod = $_SERVER['REQUEST_METHOD'];

        $base = $this->getBasePath();
        if ($base !== '/' && strpos($requestUri, $base) === 0) {
            $requestPath = substr($requestUri, strlen($base));
            if ($requestPath === false) $requestPath = '/';
        } else {
            $requestPath = $requestUri;
        }
        if ($requestPath === '') $requestPath = '/';

        foreach ($this->routes as $route) {
            // ensure route path has anchors
            $pattern = $route['path'];
            if ($pattern[0] !== '^') $pattern = '^' . $pattern;
            if (substr($pattern, -1) !== '$') $pattern .= '$';

            if ($route['method'] === $requestMethod && preg_match("#{$pattern}#", $requestPath, $matches)) {
                array_shift($matches);
                // if route requires auth, we can set a flag in globals for controllers to use
                if (!empty($route['options']['auth'])) {
                    // mark that auth is required for this route
                    $_SERVER['REQUIRES_AUTH'] = '1';
                } else {
                    unset($_SERVER['REQUIRES_AUTH']);
                }
                echo call_user_func_array($route['callback'], $matches);
                return;
            }
        }

        // not found
        http_response_code(404);
        echo json_encode(["success" => false, "message" => "Not Found"]);
    }
}
