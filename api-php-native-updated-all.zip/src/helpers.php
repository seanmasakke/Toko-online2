<?php
// Very small .env parser (no external deps)
function load_dotenv($path) {
    if (!file_exists($path)) return;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) == 2) {
            $k = trim($parts[0]);
            $v = trim($parts[1]);
            if (!isset($_ENV[$k]) && getenv($k) === false) {
                putenv("$k=$v");
                $_ENV[$k] = $v;
            }
        }
    }
}

function env($key, $default = null) {
    $v = getenv($key);
    if ($v === false) return $default;
    return $v;
}
