<?php
require_once __DIR__ . '/../helpers.php';

class UserController {
    private $pdo;
    private $jwtSecret;

    public function __construct() {
        load_dotenv(__DIR__ . '/../../.env');
        $host = env('DB_HOST', 'localhost');
        $dbname = env('DB_NAME', 'toko_online');
        $username = env('DB_USER', 'root');
        $password = env('DB_PASS', '');
        $charset = env('DB_CHAR', 'utf8mb4');

        $this->jwtSecret = env('JWT_SECRET', 'ChangeThisSecret');

        $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
        try {
            $this->pdo = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Database connection failed"]);
            exit;
        }
    }

    // Simple JWT verify (HS256)
    private function base64url_decode($data) {
        $remainder = strlen($data) % 4;
        if ($remainder) $data .= str_repeat('=', 4 - $remainder);
        return base64_decode(strtr($data, '-_', '+/'));
    }
    private function verifyJWT($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return false;
        list($headerB64, $payloadB64, $sigB64) = $parts;
        $payloadJson = $this->base64url_decode($payloadB64);
        $payload = json_decode($payloadJson, true);
        if (!$payload) return false;
        // verify signature
        $expected = rtrim(strtr(base64_encode(hash_hmac('sha256', "$headerB64.$payloadB64", $this->jwtSecret, true)), '+/', '-_'), '=');
        if (!hash_equals($expected, $sigB64)) return false;
        // check exp
        if (isset($payload['exp']) && time() > $payload['exp']) return false;
        return $payload;
    }

    private function requireAuth() {
        // check if route required auth by Router (sets $_SERVER['REQUIRES_AUTH'])
        if (empty($_SERVER['REQUIRES_AUTH'])) return null; // not required
        $h = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null);
        if (!$h) {
            http_response_code(401);
            echo json_encode(["success"=>false,"message"=>"Authorization header required"]);
            exit;
        }
        if (stripos($h, 'Bearer ') === 0) $token = trim(substr($h,7));
        else $token = $h;
        $payload = $this->verifyJWT($token);
        if (!$payload) {
            http_response_code(401);
            echo json_encode(["success"=>false,"message"=>"Invalid or expired token"]);
            exit;
        }
        return $payload;
    }

    private function jsonBody() {
        $body = file_get_contents('php://input');
        $data = json_decode($body, true);
        return is_array($data) ? $data : null;
    }

    // GET /users
    public function index() {
        $this->requireAuth();
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);

        $stmt = $this->pdo->prepare("SELECT id, username, email, created_at, updated_at FROM users ORDER BY id DESC LIMIT :limit OFFSET :offset");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $users = $stmt->fetchAll();

        return json_encode(["success" => true, "count" => count($users), "data" => $users]);
    }

    // GET /users/{id}
    public function show($id) {
        $this->requireAuth();
        $stmt = $this->pdo->prepare("SELECT id, username, email, created_at, updated_at FROM users WHERE id = :id");
        $stmt->execute(['id' => (int)$id]);
        $user = $stmt->fetch();
        if (!$user) {
            http_response_code(404);
            return json_encode(["success" => false, "message" => "User not found"]);
        }
        return json_encode(["success" => true, "data" => $user]);
    }

    // POST /users
    public function create() {
        $this->requireAuth();
        $data = $this->jsonBody();
        if (!$data) { http_response_code(400); return json_encode(["success"=>false,"message"=>"Invalid JSON body"]); }

        $username = trim($data['username'] ?? '');
        $email = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';

        // stronger validation
        if ($username === '' || $email === '' || $password === '') {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"username, email, and password are required"]);
        }
        if (strlen($username) < 3 || strlen($username) > 50) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"username must be 3-50 characters"]);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"Invalid email format"]);
        }
        if (strlen($password) < 6) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"password must be at least 6 characters"]);
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $this->pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        try {
            $stmt->execute([
                'username' => $username,
                'email' => $email,
                'password' => $passwordHash
            ]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                http_response_code(409);
                return json_encode(["success" => false, "message" => "username or email already exists"]);
            }
            http_response_code(500);
            return json_encode(["success" => false, "message" => "Database error"]);
        }

        $newId = (int)$this->pdo->lastInsertId();
        http_response_code(201);
        $stmt = $this->pdo->prepare("SELECT id, username, email, created_at, updated_at FROM users WHERE id = :id");
        $stmt->execute(['id' => $newId]);
        $newUser = $stmt->fetch();
        return json_encode(["success" => true, "data" => $newUser]);
    }

    // PUT /users/{id}
    public function update($id) {
        $this->requireAuth();
        $id = (int)$id;
        $stmt = $this->pdo->prepare("SELECT id, username, email FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $user = $stmt->fetch();
        if (!$user) {
            http_response_code(404);
            return json_encode(["success" => false, "message" => "User not found"]);
        }

        $data = $this->jsonBody();
        if (!$data) { http_response_code(400); return json_encode(["success"=>false,"message"=>"Invalid JSON body"]); }

        $username = isset($data['username']) ? trim($data['username']) : $user['username'];
        $email = isset($data['email']) ? trim($data['email']) : $user['email'];
        $password = $data['password'] ?? null;

        if ($username === '' || strlen($username) < 3 || strlen($username) > 50) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"username must be 3-50 characters"]);
        }
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"Invalid email format"]);
        }
        if (!is_null($password) && $password !== '' && strlen($password) < 6) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"password must be at least 6 characters"]);
        }

        $params = [
            'id' => $id,
            'username' => $username,
            'email' => $email
        ];
        $sql = "UPDATE users SET username = :username, email = :email";
        if (!is_null($password) && $password !== '') {
            $params['password'] = password_hash($password, PASSWORD_DEFAULT);
            $sql .= ", password = :password";
        }
        $sql .= " WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);
        try {
            $stmt->execute($params);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                http_response_code(409);
                return json_encode(["success" => false, "message" => "username or email already exists"]);
            }
            http_response_code(500);
            return json_encode(["success" => false, "message" => "Database error"]);
        }

        $stmt = $this->pdo->prepare("SELECT id, username, email, created_at, updated_at FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $updated = $stmt->fetch();
        return json_encode(["success" => true, "data" => $updated]);
    }

    // DELETE /users/{id}
    public function delete($id) {
        $this->requireAuth();
        $id = (int)$id;
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
        if (!$stmt->fetch()) {
            http_response_code(404);
            return json_encode(["success" => false, "message" => "User not found"]);
        }
        $stmt = $this->pdo->prepare("DELETE FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
        http_response_code(204);
        return '';
    }
}
