<?php
require_once __DIR__ . '/../helpers.php';

class AuthController {
    private $pdo;
    private $jwtSecret;
    private $issuer;
    private $exp;

    public function __construct() {
        load_dotenv(__DIR__ . '/../../.env');
        $host = env('DB_HOST', 'localhost');
        $dbname = env('DB_NAME', 'toko_online');
        $username = env('DB_USER', 'root');
        $password = env('DB_PASS', '');
        $charset = env('DB_CHAR', 'utf8mb4');

        $this->jwtSecret = env('JWT_SECRET', 'ChangeThisSecret');
        $this->issuer = env('JWT_ISSUER', 'api');
        $this->exp = (int)env('JWT_EXP', 3600);

        $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
        try {
            $this->pdo = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "DB connection failed"]);
            exit;
        }
    }

    private function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function sign($header, $payload) {
        $sig = hash_hmac('sha256', "$header.$payload", $this->jwtSecret, true);
        return $this->base64url_encode($sig);
    }

    private function generateJWT($userId) {
        $header = $this->base64url_encode(json_encode(["alg"=>"HS256","typ"=>"JWT"]));
        $now = time();
        $payload = $this->base64url_encode(json_encode([
            "iss" => $this->issuer,
            "iat" => $now,
            "exp" => $now + $this->exp,
            "sub" => $userId
        ]));
        $sig = $this->sign($header, $payload);
        return "$header.$payload.$sig";
    }

    public function login() {
        $body = file_get_contents('php://input');
        $data = json_decode($body, true);
        if (!is_array($data)) {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"Invalid JSON"]);
        }
        $identifier = trim($data['identifier'] ?? '');
        $password = $data['password'] ?? '';

        if ($identifier === '' || $password === '') {
            http_response_code(400);
            return json_encode(["success"=>false,"message"=>"identifier and password required"]);
        }

        // find by username or email
        $stmt = $this->pdo->prepare("SELECT id, username, email, password FROM users WHERE username = :idn OR email = :idn LIMIT 1");
        $stmt->execute(['idn'=>$identifier]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password'])) {
            http_response_code(401);
            return json_encode(["success"=>false,"message"=>"Invalid credentials"]);
        }

        $token = $this->generateJWT($user['id']);
        return json_encode(["success"=>true,"token"=>$token, "user"=>["id"=>$user['id'], "username"=>$user['username'], "email"=>$user['email']]]);
    }
}
