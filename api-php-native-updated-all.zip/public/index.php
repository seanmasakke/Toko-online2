<?php
header("Content-Type: application/json");

require_once __DIR__ . '/../src/Router.php';
require_once __DIR__ . '/../src/controllers/UserController.php';
require_once __DIR__ . '/../src/Controllers/AuthController.php';
require_once __DIR__ . '/../src/helpers.php';

$router = new Router();
$userController = new UserController();
$authController = new AuthController();

// Public route: login
$router->add('POST', '/api/v1/auth/login', [$authController, 'login']);

// Protected user routes (require auth)
$router->add('GET', '/api/v1/users', [$userController, 'index'], ['auth'=>true]);
$router->add('GET', '/api/v1/users/(\d+)', [$userController, 'show'], ['auth'=>true]);
$router->add('POST', '/api/v1/users', [$userController, 'create'], ['auth'=>true]);
$router->add('PUT', '/api/v1/users/(\d+)', [$userController, 'update'], ['auth'=>true]);
$router->add('DELETE', '/api/v1/users/(\d+)', [$userController, 'delete'], ['auth'=>true]);

$router->run();
